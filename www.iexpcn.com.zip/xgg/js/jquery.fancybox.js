<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">
<html><head>
<title>300 Multiple Choices</title>
</head><body>
<h1>Multiple Choices</h1>
The document name you requested (<code>/assets/js/fancybox/jquery.fancybox.js</code>) could not be found on this server.
However, we found documents with names similar to the one you requested.<p>Available documents:
<ul>
<li><a href="/assets/js/fancybox/jquery.mousewheel-3.0.6.pack.js%3fv=2.1.4">/assets/js/fancybox/jquery.mousewheel-3.0.6.pack.js?v=2.1.4</a> (common basename)
<li><a href="/assets/js/fancybox/jquery.fancybox.js~v=2.1.4%3fv=2.1.4">/assets/js/fancybox/jquery.fancybox.js~v=2.1.4?v=2.1.4</a> (common basename)
<li><a href="/assets/js/fancybox/jquery.fancybox.css~v=2.1.4.css%3fv=2.1.4">/assets/js/fancybox/jquery.fancybox.css~v=2.1.4.css?v=2.1.4</a> (common basename)
</ul>
</body></html>
